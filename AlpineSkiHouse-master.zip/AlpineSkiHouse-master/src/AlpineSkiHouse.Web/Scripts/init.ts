﻿import {Index} from "./Pages/Home/Index";

var index = new Index();