﻿import {MetersSkied} from "./MetersSkied";

var container = document.getElementById("metersSkiedChart");
var graph = new MetersSkied(container);
console.log("I made a graph");