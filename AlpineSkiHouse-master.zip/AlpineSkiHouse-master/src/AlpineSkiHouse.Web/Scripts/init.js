System.register(["./Pages/Home/Index"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Index_1;
    var index;
    return {
        setters:[
            function (Index_1_1) {
                Index_1 = Index_1_1;
            }],
        execute: function() {
            index = new Index_1.Index();
        }
    }
});
