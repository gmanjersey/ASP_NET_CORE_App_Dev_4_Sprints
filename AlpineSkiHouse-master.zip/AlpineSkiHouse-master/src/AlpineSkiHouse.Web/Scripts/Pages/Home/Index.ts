﻿export class Index {
    constructor() {
    }
}
