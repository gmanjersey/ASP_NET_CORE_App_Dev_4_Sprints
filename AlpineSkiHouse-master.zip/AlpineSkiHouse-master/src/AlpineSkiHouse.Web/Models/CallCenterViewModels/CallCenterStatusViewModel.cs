﻿namespace AlpineSkiHouse.Models.CallCenterViewModels
{
    public class CallCenterStatusViewModel
    {        
        public int OnlineRepresentatives { get; set; }
        public string PhoneNumber { get; set; }
    }
}
