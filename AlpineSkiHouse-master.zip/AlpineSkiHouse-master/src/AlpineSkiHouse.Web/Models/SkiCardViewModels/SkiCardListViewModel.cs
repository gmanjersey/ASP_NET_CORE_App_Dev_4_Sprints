﻿namespace AlpineSkiHouse.Models.SkiCardViewModels
{
    public class SkiCardListViewModel
    {
        public int Id { get; set; }
        public string CardHolderName { get; set; }
    }
}
