﻿using Microsoft.AspNetCore.Authorization;

namespace AlpineSkiHouse.Security
{
    public class EditSkiCardAuthorizationRequirement : IAuthorizationRequirement
    {
    }
}
