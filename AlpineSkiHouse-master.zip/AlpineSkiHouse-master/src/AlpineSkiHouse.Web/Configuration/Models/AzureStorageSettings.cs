﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AlpineSkiHouse.Configuration.Models
{
    public class AzureStorageSettings
    {
        public string AzureStorageConnectionString { get; set; }
    }
}
