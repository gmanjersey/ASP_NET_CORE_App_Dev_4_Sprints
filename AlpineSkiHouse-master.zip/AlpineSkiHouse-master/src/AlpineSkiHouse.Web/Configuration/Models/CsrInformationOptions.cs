﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AlpineSkiHouse.Configuration
{
    public class CsrInformationOptions
    {
        public string PhoneNumber { get; set; }
        public int OnlineRepresentatives { get; set; }
    }

}
