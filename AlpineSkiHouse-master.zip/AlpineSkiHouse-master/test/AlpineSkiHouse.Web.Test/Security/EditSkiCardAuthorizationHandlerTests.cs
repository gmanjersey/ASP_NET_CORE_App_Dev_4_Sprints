﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AlpineSkiHouse.Web.Tests.Security
{
    public class EditSkiCardAuthorizationHandlerTests
    {
    }
}
